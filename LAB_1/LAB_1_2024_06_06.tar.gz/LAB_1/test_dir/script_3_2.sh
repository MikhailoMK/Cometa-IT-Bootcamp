#!/bin/bash
dir=`pwd`
chown user1:lab_group -R $dir
chmod 764 -R $dir
