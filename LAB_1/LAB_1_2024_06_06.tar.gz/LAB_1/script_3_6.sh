#!/bin/bash

if [ $# -ne 2 ]; then
  echo INCORRECT CONFIGURATION
  exit
fi

if [ ! -e $1 ]; then
  echo FILE NOT FOUND
  exit
fi

NAME=$(basename $1 | cut -d '.' -f 1)_$(date +%Y_%m_%d)

tar -czvf $2/$NAME.tar.gz -C $(dirname $1) $(basename $1)
