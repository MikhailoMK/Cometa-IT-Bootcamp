#!/bin/bash
echo Hello `whoami`!
